const aliases = Object.freeze({
  rend: "main", main: "main", mak: "coder", coder: "coder",
  lyra: "researcher", researcher: "researcher", architect: "architect",
  reviewer: "reviewer", fast: "fast", progre: "progre", designer: "designer",
});

// Mesh owns authenticated ingress; this adapter only selects configured roles.
// Never turn an arbitrary request field into a workspace path or model override.
export function resolveMeshTarget(body, config, defaultAgent = "rend") {
  if (typeof body?.text !== "string" || !body.text.trim()) throw new Error("empty_message");
  if (body.text.length > 32000) throw new Error("message_too_long");
  let text = body.text.trim();
  let requested = String(body.target_agent || body.agent_id || defaultAgent).toLowerCase();
  const command = text.match(/^\/agent\s+([a-z0-9_-]+)\s+([\s\S]+)$/i);
  if (command) [, requested, text] = command;
  else if (/^\/agent(?:\s|$)/i.test(text)) throw new Error("usage: /agent <rend|mak|lyra|architect|reviewer|fast> <message>");
  const agentId = aliases[requested.toLowerCase()];
  if (!agentId || !Object.hasOwn(config?.agents?.entries || {}, agentId)) throw new Error("unknown_agent");
  return { agentId, text };
}
