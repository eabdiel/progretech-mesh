import assert from "node:assert/strict";
import test from "node:test";
import { resolveMeshTarget } from "./routing.js";
const config = { agents: { entries: { main: {}, coder: {}, researcher: {}, architect: {}, reviewer: {}, fast: {} } } };
test("existing Mesh Rend identity resolves to existing OpenClaw main", () => {
  assert.deepEqual(resolveMeshTarget({agent_id: "rend", text: "hello"}, config), {agentId: "main", text: "hello"});
});
test("console and API text selects a distinct role", () => {
  assert.deepEqual(resolveMeshTarget({agent_id: "rend", text: "/agent mak inspect\ncode"}, config), {agentId: "coder", text: "inspect\ncode"});
  assert.equal(resolveMeshTarget({target_agent: "lyra", text: "brief"}, config).agentId, "researcher");
});
test("unknown and missing roles fail closed", () => {
  for (const id of ["root", "../../etc", "constructor", "__proto__"]) {
    assert.throws(() => resolveMeshTarget({agent_id: id, text: "hello"}, config), /unknown_agent/);
  }
  assert.throws(() => resolveMeshTarget({agent_id: "mak", text: "hello"}, {agents:{entries:{main:{}}}}), /unknown_agent/);
});
test("invalid payloads never start agent work", () => {
  for (const text of ["", " ", 42, null]) assert.throws(() => resolveMeshTarget({text}, config), /empty_message/);
  assert.throws(() => resolveMeshTarget({text: "x".repeat(32001)}, config), /message_too_long/);
  assert.throws(() => resolveMeshTarget({text: "/agent mak"}, config), /usage/);
});
